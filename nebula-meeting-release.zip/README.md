# Nebula Meeting (星云会议)

Nebula 是一个基于 WebRTC 的下一代即时会议平台，提供高质量的视频通话、屏幕共享、实时聊天和文件传输功能。项目采用现代化的技术栈，结合了 React 前端与 Node.js 后端，并集成了令人惊叹的 3D 交互式背景。

## ✨ 主要特性

*   **多模式会议支持**：
    *   **WebRTC (P2P)**: 适合小型会议，低延迟，支持 4K 屏幕共享。
    *   **Jitsi Meet**: 适合大型会议，功能丰富。
    *   **Agora (声网)**: 企业级稳定性与全球低延迟支持。
*   **沉浸式体验**: 基于 Three.js 的高性能 3D 粒子波浪背景 ("Electric Wave")。
*   **安全可靠**: 支持房间密码保护、管理员强制关闭房间。
*   **协作工具**:
    *   实时文字聊天。
    *   P2P 文件传输（支持拖拽发送）。
    *   屏幕共享（支持音频共享）。
*   **现代化 UI**: 响应式设计，支持暗色模式，Apple 风格的毛玻璃交互元素。

## 🛠 技术栈

*   **Frontend**: React 18, Vite, Tailwind CSS, Three.js (@react-three/fiber), Socket.io-client
*   **Backend**: Node.js, Express, Socket.io
*   **Protocols**: WebRTC, WebSocket

---

## 🚀 部署指南

本指南将帮助您在本地开发环境或生产服务器上部署 Nebula Meeting。

### 📋 环境要求

*   **Node.js**: v18.0.0 或更高版本
*   **npm**: v9.0.0 或更高版本
*   **Git**

### 💻 本地开发 (Development)

1.  **克隆仓库**
    ```bash
    git clone https://github.com/fastnas2023/freemeeting.git
    cd freemeeting
    ```

2.  **安装依赖**
    分别安装前端和后端的依赖：
    ```bash
    # 安装服务端依赖
    cd server
    npm install

    # 安装客户端依赖
    cd ../client
    npm install
    ```

3.  **启动开发服务**
    您需要同时启动后端信令服务器和前端开发服务器。

    *   **终端 1 (Server)**:
        ```bash
        cd server
        npm start
        # 服务器将运行在 http://localhost:5001
        ```

    *   **终端 2 (Client)**:
        ```bash
        cd client
        npm run dev
        # 客户端将运行在 http://localhost:5173
        ```

4.  **访问应用**
    打开浏览器访问 `http://localhost:5173`。

---

### 🌐 生产环境部署 (Production)

在生产环境中，建议将前端构建为静态文件，并由后端服务器（或 Nginx）提供服务。

#### 方法一：Node.js 集成部署 (推荐)

此方法将前端构建产物放入后端目录，由 Express 服务器统一托管，适合单机部署。

1.  **构建前端**
    ```bash
    cd client
    npm run build
    ```
    构建完成后，会在 `client/dist` 目录下生成静态文件。

2.  **部署静态文件**
    将 `client/dist` 目录下的所有文件复制到 `server/public` 目录中。
    ```bash
    # 在项目根目录下执行
    mkdir -p server/public
    cp -r client/dist/* server/public/
    ```

3.  **配置后端**
    确保 `server/index.js` 已配置为服务静态文件（本项目已默认配置）：
    ```javascript
    // server/index.js
    app.use(express.static(path.join(__dirname, 'public')));
    
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });
    ```

4.  **启动服务**
    ```bash
    cd server
    npm install --production
    
    # 建议使用 pm2 管理进程
    npm install -g pm2
    pm2 start index.js --name "nebula-meeting"
    ```
    应用现在可以通过服务器的 IP 或域名访问（默认端口 5001）。

#### 方法二：Docker 容器化部署

1.  **创建 Dockerfile**
    在项目根目录下创建 `Dockerfile`：
    ```dockerfile
    # Build Stage
    FROM node:18-alpine as builder
    WORKDIR /app
    COPY client/package*.json ./client/
    RUN cd client && npm install
    COPY client/ ./client/
    RUN cd client && npm run build

    # Production Stage
    FROM node:18-alpine
    WORKDIR /app
    COPY server/package*.json ./
    RUN npm install --production
    COPY server/ ./
    # Copy built frontend assets
    COPY --from=builder /app/client/dist ./public

    EXPOSE 5001
    CMD ["node", "index.js"]
    ```

2.  **构建并运行**
    ```bash
    # 构建镜像
    docker build -t nebula-meeting .

    # 运行容器
    docker run -d -p 5001:5001 --name nebula-meeting nebula-meeting
    ```

#### 方法三：宝塔面板 (aaPanel) 部署

1.  **准备环境**
    *   在宝塔面板软件商店中安装 **PM2 管理器** 和 **Node.js 版本管理器** (安装 Node.js 18+)。
    *   (可选) 安装 Nginx 用于反向代理。

2.  **上传代码**
    *   将项目代码上传到服务器目录 (例如 `/www/wwwroot/nebula-meeting`)。
    *   或者在目录下直接使用终端克隆仓库。

3.  **安装依赖与构建**
    在服务器终端或宝塔终端中执行：
    ```bash
    cd /www/wwwroot/nebula-meeting
    
    # 安装服务端依赖
    cd server
    npm install --production
    
    # 安装客户端依赖并构建
    cd ../client
    npm install
    npm run build
    
    # 部署静态文件到服务端目录
    cd ..
    cp -r client/dist/* server/public/
    ```

4.  **启动服务 (PM2)**
    *   打开宝塔面板 -> 网站 -> Node项目 -> 添加Node项目。
    *   **项目目录**: 选择 `/www/wwwroot/nebula-meeting/server`。
    *   **启动文件**: 选择 `index.js`。
    *   **项目名称**: `nebula-meeting`。
    *   **端口**: `5001`。
    *   提交后，服务即自动启动。

5.  **配置域名 (Nginx)**
    *   在 Node 项目设置中，绑定您的域名。
    *   或者手动创建 Nginx 站点，配置反向代理：
        ```nginx
        location / {
            proxy_pass http://127.0.0.1:5001;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
        }
        ```

#### 方法四：1Panel 面板部署

1.  **准备环境**
    *   在应用商店安装 **OpenResty** (Nginx) 和 **Node.js**。

2.  **创建网站**
    *   进入 **网站** -> **创建网站** -> **运行环境** 选择 **Node.js**。
    *   **主域名**: 填写您的域名。
    *   **代号**: `nebula-meeting`。

3.  **上传与构建**
    *   进入网站根目录，上传代码。
    *   使用终端进入目录，执行与宝塔部署相同的构建命令 (npm install & build & cp)。

4.  **配置运行**
    *   在网站设置 -> **运行配置** 中：
        *   **启动文件**: `server/index.js`
        *   **运行目录**: `/server`
        *   **端口**: `5001`
    *   保存并重启服务。

5.  **反向代理 (WebSocket 支持)**
    *   1Panel 的 Node.js 运行环境通常会自动配置反代。
    *   如果遇到 WebSocket 连接问题，请在 **配置文件** 中手动添加：
        ```nginx
        location /socket.io/ {
            proxy_pass http://127.0.0.1:5001;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
        }
        ```

---

## ⚙️ 配置说明

### 环境变量
虽然项目可以零配置运行，但建议创建 `.env` 文件来配置特定参数。

**Server (`server/.env`):**
```env
PORT=5001
# 如果使用 Agora 功能
AGORA_APP_ID=your_agora_app_id
AGORA_APP_CERTIFICATE=your_agora_certificate
```

**Client (`client/.env`):**
```env
# 生产环境后端地址 (如果前后端分离部署)
VITE_API_URL=https://meet.cn111.net
```

## 🤝 贡献
欢迎提交 Issue 和 Pull Request！

## 📄 许可证
MIT License
